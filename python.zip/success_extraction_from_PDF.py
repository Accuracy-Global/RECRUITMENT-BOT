
# importing required modules 
import PyPDF2 
import re 
# creating a pdf file object 
pdfFileObj = open('G:\college\College Project\Result_ Portage\last_time.pdf', 'rb') 
  
# creating a pdf reader object 
pdfReader = PyPDF2.PdfFileReader(pdfFileObj) 
  

  
# creating a page object 
pageObj = pdfReader.getPage(0) 
  
# extracting text from page 
myfile = pageObj.extractText()
  
# closing the pdf file object

email = re.findall(r"[a-zA-Z0-9_.]+@[a-zA-Z0-9]+\.com", myfile)
phone = re.findall(r"([+]91|)(\d{3}(-|)\d{3}(-|)\d{4})", myfile)



print("EMAILS IN TEXT DOCUMENT")
e_length = len(email)
for i in range(0,e_length):
    print(i+1, email[i])

p_length = len(phone)

print("")
print("PHONE NUMBERs IN TEXT DOCUMENT")
for i in range(0,p_length):
    print(i+1, phone[i][1])

exp = re.findall(r"experience: \d", myfile)
exp_length = len(exp)

print("")
print("EXPERIENCES IN TEXT DOCUMENT")
y = " years"
for i in range(0, exp_length):
    print(i+1, exp[i], y)


pdfFileObj.close() 
