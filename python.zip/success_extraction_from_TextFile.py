import re
myfile = open("G:\college\College Project\Result_ Portage\paper2.txt", "rt") # open lorem.txt for reading text
contents = myfile.read()

email = re.findall(r"[a-zA-Z0-9_.]+@[a-zA-Z0-9]+\.com",contents)
phone = re.findall(r"([+]91|)(\d{3}(-|)\d{3}(-|)\d{4})", contents)
exp = re.findall(r"experince : (\d\d|\d)", contents)

print("EMAILS IN TEXT DOCUMENT")
e_length = len(email)
for i in range(0,e_length):
    print(i+1, email[i])

p_length = len(phone)

print("")
print("PHONE NUMBERs IN TEXT DOCUMENT")
for i in range(0,p_length):
    print(i+1, phone[i][1])

exp_length = len(exp)
print("")
print("EXPERIENCES IN TEXT DOCUMENT")
y = " years"
for i in range(0, exp_length):
    print(i+1,"experience", exp[i], y)


