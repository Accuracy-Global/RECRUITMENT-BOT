import docx
import os
import re
print(os.getcwd())
doc = docx.Document('data.docx')
fullText = []
for para in doc.paragraphs:
    fullText.append(para.text)

end = len(fullText)
print(end)
para = "starts here"

for i in range(0, end):
    para = para + "\n" + fullText[i]


email = re.findall(r"[a-zA-Z0-9_.]+@[a-zA-Z0-9]+\.com", para)
phone = re.findall(r"([+]91|)(\d{3}(-|)\d{3}(-|)\d{4})", para)
exp = re.findall(r"experience: (\d\d|\d)", para)
print("EMAILS IN WORD DOCUMENT")
e_length = len(email)
for i in range(0,e_length):
    print(i+1, email[i])

p_length = len(phone)
e_length = len(phone)
print("")
print("PHONE NUMBERs IN WORD DOCUMENT")
for i in range(0,p_length):
    print(i+1, phone[i][1])

exp_length = len(exp)
print(exp_length)
print("")
print("EXPERIENCES IN WORD DOCUMENT")
y = " years"
for i in range(0, exp_length):
    print(i+1,"experience", exp[i], y)





