﻿namespace MultiDialogsBot.Dialogs
{
    using System;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;
    using Microsoft.Bot.Builder.Dialogs;
    using Microsoft.Bot.Connector;
    using System.Data;
    using System.Configuration;
    using Models;
    using System.Data.SqlClient;
    using System.Text;
    using System.Data;
    using System.Data.SQLite;



    [Serializable]
    public class RootDialog : IDialog<object>
    {

        private const string YesOption = "Yes";

        private const string NoOption = "No";

        //string Name = "";

        public async Task StartAsync(IDialogContext context)
        {
            context.Wait(this.MessageReceivedAsync);
        }

        private async Task MessageReceivedAsync(IDialogContext context, IAwaitable<object> result)
        {
            var activity = await result as Activity;

            await context.PostAsync("Hai, How are you..?");
            context.Wait(MessageName);
        }

        private async Task MessageName(IDialogContext context, IAwaitable<object> result)
        {
            var activity = await result as Activity;


            await context.PostAsync("May I know your full name....");

            context.Wait(MessageNameNext1);
        }

        private async Task MessageNameNext1(IDialogContext context, IAwaitable<object> result)
        {

            var activity = await result as Activity;
            string Name = activity.Text;
            const string filename = @"E:\sqlite\botdb.db";
            SQLiteConnection con;
            con = new SQLiteConnection("Data Source=" + filename + "; Version = 3; New = True; Compress = True; ");
            SQLiteDataReader sqlite_datareader;
            SQLiteCommand cmd = new SQLiteCommand("select * from resume where name='" + Name + "'", con);
            await context.PostAsync("Hello! " +activity.Text+ " Please check your below details..");
            con.Open();
            sqlite_datareader = cmd.ExecuteReader();
            if (sqlite_datareader.HasRows)
            {
                sqlite_datareader.Read();
                string name1 = sqlite_datareader["name"].ToString();
                string email1 = sqlite_datareader["email"].ToString();
                //long phoneno1 = Convert.ToInt64(sqlite_datareader["phoneno"]);
                long phoneno1 = sqlite_datareader.GetInt64(2);
                string exp1 = sqlite_datareader["exp"].ToString();
                string skills1 = sqlite_datareader["skills"].ToString();
                string precomp1 = sqlite_datareader["precomp"].ToString();
                string location1 = sqlite_datareader["location"].ToString();

                string final1 = "Name: " + name1 + "\n" + "Email Id: " + email1 + "\n" + "Phone No: " + phoneno1.ToString() + "\n" + "Experience: " + exp1 + "\n"
                                    + "Skills: " + skills1 + "\n" + "Previous Comp: " + precomp1 + "\n" + "Current Loc: " + location1;           
                await context.PostAsync(final1);
            }
            context.Wait(this.FinalDialog);
        }

        private async Task FinalDialog(IDialogContext context, IAwaitable<object> result)
        {
            await context.PostAsync("Welcome..");
        }

        /*private async Task MessageRecommedItems(IDialogContext context, IAwaitable<object> result)
        {
            var activity = await result as Activity;
            ulong account_no = Convert.ToUInt64(activity.Text);
            string recomitems = "";
            string CS = ConfigurationManager.ConnectionStrings["RecomItems"].ConnectionString;
            SqlConnection con = new SqlConnection("data source =tcp:petronasbot.database.windows.net; initial catalog = BotData1; user id = rupesh; password = bot@12345;");
            SqlCommand cmd = new SqlCommand("select * from Recom_Items where Account_No=" + account_no, con);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            //if (dr.HasRows)
            //{
            //dr.Read();
            DataTable dt = new DataTable();
            dt.Load(dr);
            int numRows = dt.Rows.Count;

            //dr.Read();
            //string his = dr["Past_History"].ToString();
            // return our reply to the user
            if (account_no == Convert.ToUInt64(activity.Text))
            {
                for (int i = 0; i < numRows; i++)
                {
                    recomitems = recomitems + " " + dt.Rows[i]["Recommended_Items"] + "\n\n";
                }
                await context.PostAsync("May be following product promotions interesting for you..");
                await context.PostAsync($"{recomitems}");
                await context.PostAsync("Are you looking for a specific product please enter the Number");
                //context.Wait(MessageRecommedItemsPrice);
                //this.ShowOptions(context);
                context.Call(new RecomDialog(), this.ResumeAfterOptionDialog);

            }


            //}
            else
            {
                context.Call(new NoDialog(), this.ResumeAfterOptionDialog);
            }
        }

        public virtual async Task showOptions(IDialogContext context, IAwaitable<IMessageActivity> result)
        {
            var message = await result;

            if (message.Text.ToLower().Contains("help") || message.Text.ToLower().Contains("support") || message.Text.ToLower().Contains("problem"))
            {
                await context.Forward(new SupportDialog(), this.ResumeAfterSupportDialog, message, CancellationToken.None);
            }
            else
            {
                this.ShowOptions(context);
            }
        }

        private void ShowOptions(IDialogContext context)
        {
            PromptDialog.Choice(context, this.OnOptionSelected, new List<string>() { YesOption, NoOption }, "We have discounts in some products, are you intrested?", "Not a valid option", 3);
        }

        private async Task OnOptionSelected(IDialogContext context, IAwaitable<string> result)
        {
            try
            {
                string optionSelected = await result;

                switch (optionSelected)
                {
                    case YesOption:
                        context.Call(new FlightsDialog(), this.ResumeAfterOptionDialog);
                        break;

                    case NoOption:
                        context.Call(new NoDialog(), this.ResumeAfterOptionDialog);
                        break;
                }

            }
            catch (TooManyAttemptsException ex)
            {
                await context.PostAsync($"Ooops! Too many attemps :(. But don't worry, I'm handling that exception and you can try again!");

                context.Wait(this.MessageReceivedAsync);
            }

        }


        private async Task ResumeAfterSupportDialog(IDialogContext context, IAwaitable<int> result)
        {
            var ticketNumber = await result;

            await context.PostAsync($"Thanks for contacting our support team. Your ticket number is {ticketNumber}.");
            context.Wait(this.MessageReceivedAsync);
        }

        private async Task ResumeAfterOptionDialog(IDialogContext context, IAwaitable<object> result)
        {
            try
            {
                var message = await result;
            }
            catch (Exception ex)
            {
                await context.PostAsync($"Failed with message: {ex.Message}");
            }
            finally
            {
                context.Wait(this.MessageReceivedAsync);
            }
        }*/
    }
}