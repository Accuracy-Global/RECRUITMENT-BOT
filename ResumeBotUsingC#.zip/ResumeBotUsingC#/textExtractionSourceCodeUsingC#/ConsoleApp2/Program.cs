﻿
using System;
using System.Data.SQLite;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;


namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            var phone = "";
            var email = "";
            var exp = "";
            var skl = "";
            string text = System.IO.File.ReadAllText(@"G:\college\College Project\Result_ Portage\next_text2.txt");
            Regex regex = new Regex(@"\d{10}");
            Regex regex1 = new Regex(@"[a-zA-Z0-9_.]+@[a-zA-Z0-9]+\.com");
            Regex regex2 = new Regex(@"experience: \d");
            Regex regex3 = new Regex(@"SKILLS: (\w+) (\w+)");
            Match match = regex.Match(text);
            Match match1 = regex1.Match(text);
            Match match2 = regex2.Match(text);
            Match match3 = regex3.Match(text);
            if (match.Success)
            {
                phone = match.Value;
                Console.WriteLine("Phone number is reading");
            }
            if (match1.Success)
            {
                email = match1.Value;
                Console.WriteLine("Email is reading");
            }
            if (match2.Success)
            {
                exp = match2.Value;
                Console.WriteLine("Experience is reading");
            }
            if (match3.Success)
            {
                skl = match3.Value;
                Console.WriteLine(skl);
            }
            Console.WriteLine("Hello World!");
            string createQuery = @"CREATE TABLE IF NOT EXISTS [Mytable9]([Id] INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,[Email] NVARCHAR(2048) NULL,[Phone] NVARCHAR(2048) NULL, [Skills] NVARCHAR(2048) NULL, [Exp] NVARCHAR(2048) NULL)";
            //System.Data.SQLite.SQLiteConnection.CreateFile("sample.db3");
            using (System.Data.SQLite.SQLiteConnection conn = new System.Data.SQLite.SQLiteConnection("data source = sample.db3"))
            {
                using (System.Data.SQLite.SQLiteCommand cmd = new System.Data.SQLite.SQLiteCommand(conn))
                {
                    conn.Open();
                    cmd.CommandText = createQuery;
                    cmd.ExecuteNonQuery();
                    cmd.CommandText = "Insert into Mytable9(Email,Phone,Skills,Exp) values ('" + email + "', '" + phone + "', '" + skl + "', '" + exp + "')";
                    cmd.ExecuteNonQuery();
            
                    cmd.CommandText = "select * from Mytable9";
                    using (System.Data.SQLite.SQLiteDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Console.WriteLine(reader["Email"] + "\n" + reader["Phone"] + "\n" + reader["Skills"] + "\n" + reader["Exp"]);
                            Console.Clear();

                        }
                        conn.Close(); 
                    }


                }
            }
            Console.ReadLine();
        }
    }
}
