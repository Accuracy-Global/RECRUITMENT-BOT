# -*- coding: utf-8 -*-
"""
Created on Tue Apr 16 17:09:12 2019

@author: RAJESH
"""

# -*- coding: utf-8 -*-
"""
Created on words.txtTue Apr 16 15:26:01 2019

@author: RAJESH
"""


# importing required modules 
import PyPDF2 
import re 
# creating a pdf file object 
pdfFileObj = open('G:\college\College Project\Result_ Portage\Resume_Rajesh.pdf', 'rb') 
  
# creating a pdf reader object 
pdfReader = PyPDF2.PdfFileReader(pdfFileObj) 
  

  
# creating a page object 
pageObj = pdfReader.getPage(0) 
  
# extracting text from page 
myfile = pageObj.extractText()
  
# closing the pdf file object 

new_file = myfile.replace(",", "")
#Taken Email from PDF
email = re.findall(r"[a-zA-Z0-9_.]+@[a-zA-Z0-9]+\.com", myfile)
#PHone number from PDF file
phone = re.findall(r"\d{10}", myfile)
#skills from PDF file
skills = re.findall(r"SKILLS\s+((?:\w+(?:\s+|$)){4})",new_file)
#Experience from PDF
exp = re.findall(r"experience",new_file)

#Extracting name from PDF
splitted = new_file.split()
fname = splitted[0]
lname = splitted[1]

#required details stored into fallowing variables
name = fname + " " + lname
skills = skills[0]
email = email[0]
phone = phone[0]
if len(exp) == 0:
    exp = 0

import sqlite3

conn = sqlite3.connect('test.db')
print("Opened database successfully");

conn.execute('''CREATE TABLE IF NOT EXISTS RTDATA
         (NAME TEXT NOT NULL,
         EMAIL           TEXT    NOT NULL,
         PHONE           INT     NOT NULL,
         EXP       REAL(2),
         SKILLS       REAL);''')
print("Table created successfully");

conn.execute("INSERT INTO RTDATA (NAME, EMAIL,PHONE,EXP,SKILLS) VALUES (?, ?, ?, ?, ?)",
          (name, email,phone,exp,skills))




cursor = conn.execute("SELECT *  from RTDATA")
for row in cursor:
   print("name: = ", row[0])
   print("email: = ", row[1])
   print("phone: = ", row[2])
   print("experinece: = ", row[3],"years")
   print("skills:  = ", row[4])

print("Operation done successfully");
conn.close()

    
pdfFileObj.close()   
