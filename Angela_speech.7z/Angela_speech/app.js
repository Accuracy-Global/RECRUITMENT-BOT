/*-----------------------------------------------------------------------------
A speech to text bot for the Microsoft Bot Framework. 
-----------------------------------------------------------------------------*/

// This loads the environment variables from the .env file
require('dotenv-extended').load();

/*var builder = require('botbuilder'),
    fs = require('fs'),
    needle = require('needle'),
    restify = require('restify'),
    request = require('request'),
    url = require('url'),
    speechService = require('./speech-service.js');
*/
var restify = require('restify');
var builder = require('botbuilder');
var botbuilder_azure = require("botbuilder-azure");
var fs = require('fs'),
    needle = require('needle'),
    request = require('request'),
    url = require('url'),
    speechService = require('./speech-service.js');
//=========================================================
// Bot Setup
//=========================================================

// Setup Restify Server
var server = restify.createServer();
server.listen(process.env.port || process.env.PORT || 3978, function () {
    console.log('%s listening to %s', server.name, server.url);
});

// Create chat bot
var connector = new builder.ChatConnector({
    appId: process.env.MICROSOFT_APP_ID,
    appPassword: process.env.MICROSOFT_APP_PASSWORD
});

server.post('/api/messages', connector.listen());

// Bot Storage: Here we register the state storage for your bot. 
// Default store: volatile in-memory store - Only for prototyping!
// We provide adapters for Azure Table, CosmosDb, SQL Azure, or you can implement your own!
// For samples and documentation, see: https://github.com/Microsoft/BotBuilder-Azure
var inMemoryStorage = new builder.MemoryBotStorage();
//var tableName = 'botdata';
//var azureTableClient = new botbuilder_azure.AzureTableClient(tableName, process.env['AzureWebJobsStorage']);
//var tableStorage = new botbuilder_azure.AzureBotStorage({ gzipData: false }, azureTableClient);
/*var bot = new builder.UniversalBot(connector, function (session) {
    if (hasAudioAttachment(session)) {
        var stream = getAudioStreamFromMessage(session.message);
        speechService.getTextFromAudioStream(stream)
            .then(function (text) {
                session.send(processText(text));
            })
            .catch(function (error) {
                session.send('Oops! Something went wrong. Try again later.');
                console.error(error);
            });
    } else {
        session.send('Did you upload an audio file? I\'m more of an audible person. Try sending me a wav file');
    }
}).set('storage', inMemoryStorage); // Register in memory storage
*/

/*var tableName = 'botdata';
var azureTableClient = new botbuilder_azure.AzureTableClient(tableName, process.env['AzureWebJobsStorage']);
var tableStorage = new botbuilder_azure.AzureBotStorage({ gzipData: false }, azureTableClient);
*/
var bot = new builder.UniversalBot(connector,[
    function (session) {
        session.send("Welcome to the HR Portal, I am Angela.");
        builder.Prompts.text(session, 'What is your complete name?');
        }, 
    function (session, results,next) {
        session.userData.personName = results.response;
        session.send('Hello %s', results.response);
        next();
        },
    function (session, results,next) {
        builder.Prompts.text(session, "How old are you?");
        next();
        },
    function (session, results,next) {
        session.userData.personAge = results.response;
        builder.Prompts.text(session, "Where do you currently live?");
        next();
        },
    function (session, results,next) {
        session.userData.personCity = results.response;
        builder.Prompts.text(session, "Are you currently working? If yes, where? If no, when and where was your last engagement?");
        next();
        },
    function (session, results,next) {
        session.userData.personWorkornot = results.response;
        builder.Prompts.text(session, "How many years of experience you have?");
        next();
        },
    function (session, results,next) {
        session.userData.personWorkExp = results.response;
        builder.Prompts.text(session, "Which type of company your working? Its service based or product based?");
        next();
        },    
    function (session, results,next) {
        session.userData.personWorkCompany = results.response;
        builder.Prompts.text(session, "Are you actively searching for opportunities?");
        next();
        },
    function (session, results,next) {
        session.userData.personOpportunities = results.response;
        builder.Prompts.text(session, "Do you have other pending applications?");
        next();
        },
    function (session, results,next) {
        session.userData.personApplications = results.response;
        builder.Prompts.text(session, "Why are you looking for other opportunities?");
        next();
        },
    function (session, results,next) {
        session.userData.personOtherOpport = results.response;
        builder.Prompts.text(session, "If chosen for the job, when can you start working");
        next();
        },
    function (session, results,next) {
        session.userData.personStartWork = results.response;
        builder.Prompts.text(session, "What attracted you to apply for this position");
        next();
        },
    function (session, results,next) {
        session.userData.personAttraction = results.response;
        builder.Prompts.text(session, "Tell me something about yourself");
        next();
        },
    function (session, results,next) {
        session.userData.personSelfIntro = results.response;
        builder.Prompts.text(session, "What is your current salary?");
        next();
        },
    function (session, results,next) {
        session.userData.personCurrSal = results.response;
        builder.Prompts.text(session, "How much do you expect to earn with the position that you are applying for?");
        next();
        },
    function (session, results) {
        //session.send(`Please check your details: <br/>Name: ${session.userData.personName} <br/>Age: ${session.userData.personAge} <br/>City: ${session.userData.personCity} <br/>Current working status: ${session.userData.personWorkornot}`);
        session.userData.personExpectSal = results.response;
        session.send("Thank you for the details. We will get back to you..");
        session.endDialog();
        }
    ]).set('storage', inMemoryStorage);
//=========================================================
// Utilities
//=========================================================
function hasAudioAttachment(session) {
    return session.message.attachments.length > 0 &&
        (session.message.attachments[0].contentType === 'audio/wav' ||
            session.message.attachments[0].contentType === 'application/octet-stream');
}

function getAudioStreamFromMessage(message) {
    var headers = {};
    var attachment = message.attachments[0];
    if (checkRequiresToken(message)) {
        // The Skype attachment URLs are secured by JwtToken,
        // you should set the JwtToken of your bot as the authorization header for the GET request your bot initiates to fetch the image.
        // https://github.com/Microsoft/BotBuilder/issues/662
        connector.getAccessToken(function (error, token) {
            var tok = token;
            headers['Authorization'] = 'Bearer ' + token;
            headers['Content-Type'] = 'application/octet-stream';

            return needle.get(attachment.contentUrl, { headers: headers });
        });
    }

    headers['Content-Type'] = attachment.contentType;
    return needle.get(attachment.contentUrl, { headers: headers });
}

function checkRequiresToken(message) {
    return message.source === 'skype' || message.source === 'msteams';
}
/*
function processText(text) {
    var result = 'You said: ' + text + '.';

    if (text && text.length > 0) {
        var wordCount = text.split(' ').filter(function (x) { return x; }).length;
        result += '\n\nWord Count: ' + wordCount;

        var characterCount = text.replace(/ /g, '').length;
        result += '\n\nCharacter Count: ' + characterCount;

        var spaceCount = text.split(' ').length - 1;
        result += '\n\nSpace Count: ' + spaceCount;

        var m = text.match(/[aeiou]/gi);
        var vowelCount = m === null ? 0 : m.length;
        result += '\n\nVowel Count: ' + vowelCount;
    }

    return result;
}
*/
//=========================================================
// Bots Events
//=========================================================

// Sends greeting message when the bot is first added to a conversation
bot.on('conversationUpdate', function (message) {
    if (message.membersAdded) {
        message.membersAdded.forEach(function (identity) {
            if (identity.id === message.address.bot.id) {
                var reply = new builder.Message()
                    .address(message.address)
                    .text('Hi! I am Angela.');
                bot.send(reply);
            }
        });
    }
});